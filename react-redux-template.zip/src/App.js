import React from "react";
import { BrowserRouter as Router } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";


import Routes from "./routes";
import Header from "./components/header";
 

const App = () => {
  return (
    <div>
      <Router>
        <Header/>

        <div className="container mt-3">
            <Routes/>  
        </div>
      </Router>
    </div>
  )
}

export default App

 
