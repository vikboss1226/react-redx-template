import {
  CREATE_DOCTOR,
  RETRIEVE_DOCTORS,
  UPDATE_DOCTOR,
  DELETE_DOCTOR,
  DELETE_ALL_DOCTORS
} from "./types";

import DoctorInfoService from "../services/doctor.service";

export const createDoctor = (title, description) => async (dispatch) => {
  try {
    const res = await DoctorInfoService.create({ title, description });

    dispatch({
      type: CREATE_DOCTOR,
      payload: res.data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const retrieveDoctors = () => async (dispatch) => {
  try {
    const res = await DoctorInfoService.getAll();

    dispatch({
      type: RETRIEVE_DOCTORS,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
  }
};

export const updateDoctor = (id, data) => async (dispatch) => {
  try {
    const res = await DoctorInfoService.update(id, data);

    dispatch({
      type: UPDATE_DOCTOR,
      payload: data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const deleteDoctor = (id) => async (dispatch) => {
  try {
    await DoctorInfoService.delete(id);

    dispatch({
      type: DELETE_DOCTOR,
      payload: { id },
    });
  } catch (err) {
    console.log(err);
  }
};

export const deleteAllDoctors = () => async (dispatch) => {
  try {
    const res = await DoctorInfoService.deleteAll();

    dispatch({
      type: DELETE_ALL_DOCTORS,
      payload: res.data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const findDoctorsByTitle = (title) => async (dispatch) => {
  try {
    const res = await DoctorInfoService.findByTitle(title);

    dispatch({
      type: RETRIEVE_DOCTORS,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
  }
};