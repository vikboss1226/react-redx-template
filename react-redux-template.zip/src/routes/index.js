import React from 'react'
import {  Switch, Route } from "react-router-dom";
import AddDoctor from "../components/add-doctor.component";
import Doctor from "../components/doctor.component";
import DoctorsList from "../components/doctors-list.component";

const Routes = () => {
    return (
        <div>
            <Switch>
            <Route exact path={["/", "/doctors"]} component={DoctorsList} />
            <Route exact path="/add" component={AddDoctor} />
            <Route path="/doctors/:id" component={Doctor} />
          </Switch>
        </div>
    )
}

export default Routes
