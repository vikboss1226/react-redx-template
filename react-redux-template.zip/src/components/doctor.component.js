import React from 'react'

const  Doctor= () => {
  return (
    <div>
      <h2>Doctor View Component</h2>
    </div>
  )
}

export default Doctor
