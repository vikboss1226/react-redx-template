import React from 'react'
import { Link } from "react-router-dom";

const Header = () => {
    return (
        <div>
              <nav className="navbar navbar-expand navbar-dark bg-dark">
          <Link to={"/doctors"} className="navbar-brand">
            MediSez
          </Link>
          <div className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link to={"/doctors"} className="nav-link">
                List of Doctors
              </Link>
            </li>
            <li className="nav-item">
              <Link to={"/add"} className="nav-link">
                Add Doctor
              </Link>
            </li>
          </div>
        </nav>
        </div>
    )
}

export default Header
