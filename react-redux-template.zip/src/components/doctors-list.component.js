import React from 'react'

const  DoctorsList = () => {
  return (
    <div>
      <h2>List Doctors Component</h2>
    </div>
  )
}

export default DoctorsList
