import React from 'react'

const AddDoctor = () => {
  return (
    <div>
      <h2>Add Doctor Component</h2>
    </div>
  )
}

export default AddDoctor
